const a = 10;
const b = 20;
console.log(a + b);

const c = a + b;

const d = c * a;