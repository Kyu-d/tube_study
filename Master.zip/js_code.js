const a = 10;

const mul = a * 10;

const b = 0;
